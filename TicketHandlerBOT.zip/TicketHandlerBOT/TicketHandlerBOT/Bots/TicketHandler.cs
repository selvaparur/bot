﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using AdaptiveCards;
using Newtonsoft.Json;
using System.IO;
using ALM.IntentProcessor;
using System.Net.Http;
using System.Web;

namespace TicketHandlerBOT.Bots
{
    public class TicketHandler : ActivityHandler
    {
        IGetIntents _getIntents;
        public TicketHandler(IGetIntents getIntents)
        {
            _getIntents = getIntents;
        }

        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            //return turnContext.SendActivityAsync(MessageFactory.Text("Hi, Welcome to ALM Integrated Bot!!!. I can talk to Rally / JIRA and get you the User Story Status, Details etc..,"), cancellationToken);
            await turnContext.SendActivityAsync(MessageFactory.Attachment(GetAttachment(GetWelcome())), cancellationToken);
            await turnContext.SendActivityAsync(MessageFactory.Attachment(GetHelps()), cancellationToken);
            await turnContext.SendActivityAsync(MessageFactory.Text("How can I help you ?"), cancellationToken);
        }
        

        protected override Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            string strResponse = string.Empty;
            strResponse = _getIntents.ProcessIntent(turnContext);

            //strResponse = AppDomain.CurrentDomain.BaseDirectory;
            //strResponse = MakeRequest(turnContext.Activity.Text);

            /*   string strMessage = turnContext.Activity.Text.ToLower();
               string strResponse = string.Empty;

               if (strMessage.Contains("hi"))
               {
                   strResponse = "Hi, How are you doing...";
               }
               else if (strMessage.Contains("doing good") || strMessage.Contains("doing great") || strMessage.Contains("good"))
               {
                   strResponse = "hmm Super... :)";
               }
               else if (strMessage.Contains("what is the time now"))
               {
                   strResponse = $"Now the time is => {DateTime.Now.ToShortTimeString()}";
               }
               else if (strMessage.Contains("what is the name of the month"))
               {
                   strResponse = $"The month is => {DateTime.Now.GetDateTimeFormats()[131].Split(' ')[0]}";
               }
               else if (strMessage.Contains("create a ticket"))
               {
                   strResponse = "Hmmm... Why not, \n Could you please provide the details like \n Server Name: \n IP Address: \n Account-ID: \n";
               }
               else if (strMessage.Contains("get me the status of"))
               {
                   strResponse = "User Story : US1000 \n Status : In-Progress \n";
               }
               else if (strMessage.Contains("get me the details of"))
               {
                   strResponse = "User Story : US1000 \n Scrum Team : Nitro \n Assigned To : Selva \n Story Points : 8 \n Status : In-Progress \n No Of Tasks : 4";
               }
               else if (strMessage.Contains("thanks") || strMessage.Contains("thank you"))
               {
                   strResponse = "You are welcome, have a great day!!!";
               }
               else if (strMessage.Contains("help"))
               {
                   strResponse = "Use the following PHRASES to interact with the BOT effectively.. \n\n Greetings => hi. \n\n To get the current time => what is the time now. \n\n To get the status of a user story => get me the status of. \n\n To get the details of a user story => get me the details of.";
               }
               else
               {
                   strResponse = "Pardon...";
               }
               */

            /*AdaptiveCard wccard = new AdaptiveCard(
                new AdaptiveSchemaVersion("1.0"));

            wccard.BackgroundImage = new AdaptiveBackgroundImage(new Uri(GetResourcePath() + @"Images\BlockBackground.jfif"));

            AdaptiveTextBlock tb = new AdaptiveTextBlock();
            tb.Text = strResponse;
            tb.Color = AdaptiveTextColor.Dark;
            tb.Wrap = true;

            wccard.Body.Add(tb); */

            return turnContext.SendActivityAsync(MessageFactory.Text(strResponse), cancellationToken);
        }

        private AdaptiveCard GetWelcome()
        {
            AdaptiveCard wccard = new AdaptiveCard(
                new AdaptiveSchemaVersion("1.0"));

            wccard.BackgroundImage = new AdaptiveBackgroundImage(new Uri(GetResourcePath() + @"Images\BlockBackground.jfif"));

            AdaptiveTextBlock tb= new AdaptiveTextBlock();
            tb.Text = "Hi, I'm ALM Integrated Bot";
            tb.Color = AdaptiveTextColor.Light;
            tb.Size = AdaptiveTextSize.Large;

            wccard.Body.Add(tb);

            AdaptiveImage adaptiveImage = new AdaptiveImage(new Uri(GetResourcePath() + @"Images\HomeRobo.png"));
            wccard.Body.Add(adaptiveImage);

            tb = new AdaptiveTextBlock();
            tb.Text = " I can talk to Rally / JIRA and get you the details required ...";
            tb.Color = AdaptiveTextColor.Light;

            wccard.Body.Add(tb);

            return wccard;
        }

        private Attachment GetHelps()
        {
           string strpath = GetResourcePath().Replace("Resources","Cards") + @"help.json";
            string strContent = File.ReadAllText(strpath);

            var attch = new Attachment() {
                ContentType = "application/vnd.microsoft.card.adaptive",
                Content = JsonConvert.DeserializeObject(strContent)
            };

            return attch;
        }

        private string GetResourcePath()
        {
            string strpath = string.Empty;

            if (AppDomain.CurrentDomain.BaseDirectory.Contains(@"bin\Debug\netcoreapp2.1\"))
            {
                strpath = AppDomain.CurrentDomain.BaseDirectory.Replace(@"\bin\Debug\netcoreapp2.1\", @"\Resources\");
            }
            else
                strpath = AppDomain.CurrentDomain.BaseDirectory + (@"\Resources\");

            return strpath;
        }

        private Attachment GetAttachment(AdaptiveCard card)
        {
            Attachment attachment = new Attachment();

            string strContent = string.Empty;

            if (card != null)
            {
                strContent = card.ToJson();

                if (!string.IsNullOrEmpty(strContent))
                {
                    attachment = new Attachment()
                    {
                        ContentType = "application/vnd.microsoft.card.adaptive",
                        Content = JsonConvert.DeserializeObject(strContent)
                    };
                }
                
            }
            return attachment;
        }


    }
}
