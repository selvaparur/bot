﻿using System;

namespace ALM.Domain
{
    public class Class1
    {
    }
}
