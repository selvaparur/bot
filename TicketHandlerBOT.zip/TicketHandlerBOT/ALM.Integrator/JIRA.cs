﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;

using ALM.Domain;
using Newtonsoft.Json;

namespace ALM.Integrator
{
    public class JIRA
    {
       

        public JIRA()
        {
       
        }

        public string GetUserStoryDetails(string strUSNo)
        {
            string strResult = string.Empty;

            try
            {
                UserStory userStory = new UserStory();

                try
                {                       
                    CommunicateALM communicateALM = new CommunicateALM();
                    communicateALM.GetVerbs(Constants.JIRAStoryNumber + strUSNo, ref userStory);
                    
                }
                catch (Exception ex)
                {
                    strResult = "Error in JIRA file" + ex.Message;
                }                

                return GenerateUserStoryDetailsResponse(userStory);
            }
            catch (Exception ex)
            {

            }

            return strResult;
        }        

        private static string GenerateUserStoryDetailsResponse(UserStory userStory)
        {
            string strResult = string.Empty;

            StringBuilder stringBuilder = new StringBuilder();

            try
            {
                if (userStory != null)
                {

                    stringBuilder.Append($"Here are the details for User Story : {userStory.StoryNumber} \n");
                    stringBuilder.Append($"\n");

                    stringBuilder.Append($"User Story Number : {userStory.StoryNumber} \n");
                    stringBuilder.Append($"Story Description : {userStory.StoryDescription} \n");
                    stringBuilder.Append($"Story Owner : {userStory.StoryOwner} \n");
                    stringBuilder.Append($"Status : {userStory.Status} \n");
                    stringBuilder.Append($"Estimation : {userStory.Estimation} \n");
                    stringBuilder.Append($"\n");

                    if (userStory.TaskDetails.Length > 0)
                    {
                        int i = 0;
                        foreach (taskDetails taskDetails in userStory.TaskDetails)
                        {
                            if (i == 0)
                            {
                                stringBuilder.Append($"Task Details : \n");
                                stringBuilder.Append($"\n");
                                i++;
                            }

                            stringBuilder.Append($"Task Id : {taskDetails.TaskId} \n");
                            stringBuilder.Append($"Task Description : {taskDetails.TaskDescription} \n");
                            stringBuilder.Append($"Task Status : {taskDetails.TaskStatus} \n");
                            stringBuilder.Append($"Task Owner : {taskDetails.TaskOwner} \n");
                            stringBuilder.Append($"\n");

                        }
                    }
                    else
                        stringBuilder.Append($"Task Details: No task available \n");

                    strResult = Convert.ToString(stringBuilder);
                }
            }
            catch (Exception ex)
            {

            }

            return strResult;
        }
    }
}
