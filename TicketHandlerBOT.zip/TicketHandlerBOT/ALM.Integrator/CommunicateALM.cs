﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using Newtonsoft.Json;

namespace ALM.Integrator
{
  public  class CommunicateALM
    {
        public void GetVerbs<T>(string strInupt, ref T t)
        {   
            using (var client = new HttpClient())
            {
                string strURI = string.Empty;

                //JObject jObject = JsonParsor.GetConfigurationJson();
                //strURI = jObject["JIRA"]["endpoint"].ToString();
                strURI = @"https://phitwiki.cognizant.com/AgileChatBot/Jira/storyDetails";

                client.BaseAddress = new Uri(strURI);

                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));



                var response = client.GetAsync(strInupt).Result;

                if (response.IsSuccessStatusCode)
                {
                    var r = response.Content.ReadAsStringAsync().Result;                    
                    t = JsonConvert.DeserializeObject<T>(r);
                }

            }
        }
    }
}
