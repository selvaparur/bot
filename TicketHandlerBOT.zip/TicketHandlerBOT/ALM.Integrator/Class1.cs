﻿using System;

namespace ALM.Integrator
{
    public class Class1
    {
    }
}
