﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;

using ALM.Domain;
using ALM.Integrator;
using ALM.Core;

namespace ALM.IntentProcessor
{
    public class GetIntents : IGetIntents
    {
        static JObject jObject;
        JIRA jIRA = new JIRA();
        IUtilities _utilities;
        public GetIntents(IUtilities utilities)
        {
            _utilities = utilities;
            //jObject = JsonParsor.GetConfigurationJson();
        }

        public string GetIntent(string strQuery)
        {
            var strReturn = string.Empty;
            try
            {

                var client = new HttpClient();
                var queryString = HttpUtility.ParseQueryString(string.Empty);

                // This app ID is for a public sample app that recognizes requests to turn on and turn off lights

                //var luisAppId = jObject["luis"]["appid"];// "4e30edff-7662-42b1-a404-086f1a3f9f24";
                //var endpointKey = jObject["luis"]["endpointkey"].ToString(); //"870b6a1afe1f476d88b6786c612ed3de";
                var luisAppId = "4e30edff-7662-42b1-a404-086f1a3f9f24";
                var endpointKey = "870b6a1afe1f476d88b6786c612ed3de";

                // The request header contains your subscription key
                client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", endpointKey);

                // The "q" parameter contains the utterance to send to LUIS
                queryString["q"] = strQuery;

                // These optional request parameters are set to their default values
                queryString["timezoneOffset"] = "0";
                queryString["verbose"] = "false";
                queryString["spellCheck"] = "false";
                queryString["staging"] = "false";

                //var endpointUri = jObject["luis"]["endpoint"].ToString() + luisAppId + "?" + queryString;
                var endpointUri = "https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/" + luisAppId + "?" + queryString;

                //var response = await client.GetAsync(endpointUri);
                var response = client.GetAsync(endpointUri);


                var strResponseContent = response.Result.Content.ReadAsStringAsync();

                // Display the JSON result from LUIS
                strReturn =  strResponseContent.Result.ToString();

            }
            catch(Exception ex)
            {

            }
            return strReturn;
        }

        public string ProcessIntent(ITurnContext<IMessageActivity> turnContext)
        {
            
            string strReturn = "";
            

            try
            {
                string strIntent = string.Empty;
                Intents intents = null;
                if (turnContext != null)
                {
                    strIntent = GetIntent(turnContext.Activity.Text);
                    intents = _utilities.IntentDetails(strIntent);

                    if (intents != null)
                    {
                        
                        if (!string.IsNullOrEmpty(intents.topScoringIntent.intent))
                        {
                            strIntent = intents.topScoringIntent.intent;
                            switch (strIntent)
                            {
                                case Constants.UserStoryStaus:
                                    // ALM Call will go over here
                                    strReturn = strIntent;
                                    break;

                                case Constants.UserStoryDetails:
                                    // ALM Call will go over here  
                                    //strReturn = strIntent;
                                    string strag = "";
                                    if(intents.entities[0].entity.Contains("2"))
                                    { strag = "AA-2"; }
                                    else if (intents.entities[0].entity.Contains("3"))
                                    {
                                        strag = "AA-3";
                                    }
                                        strReturn = jIRA.GetUserStoryDetails(strag);
                                    break;

                                case Constants.Greetings:
                                    // ALM Call will go over here
                                    strReturn = Constants.GreetingMessage;
                                    break;

                                case Constants.Cancel:
                                    // ALM Call will go over here
                                    strReturn = strIntent;
                                    break;

                                case Constants.None:
                                    // ALM Call will go over here
                                    strReturn = strIntent;
                                    break;

                                default:
                                    // pardon
                                    break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                strReturn = "Exception Occured : " + ex.Message;
            }

            return strReturn;

        }
    }
}
