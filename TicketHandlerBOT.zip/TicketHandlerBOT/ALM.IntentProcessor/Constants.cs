﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using ALM.Domain;

namespace ALM.IntentProcessor
{
    public static class Constants
    {
        public const string UserStories = "UserStories";
        public const string Greetings = "Greetings";
        public const string Cancel = "Cancel";
        public const string UserStoryStaus = "UserStoryStaus";
        public const string UserStoryDetails = "UserStoryDetails";
        public const string None = "None";

        public const string GreetingMessage = "Hi, How are you doing?";
    }
}
