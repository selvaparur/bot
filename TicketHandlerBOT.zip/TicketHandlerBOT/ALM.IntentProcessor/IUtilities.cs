﻿using ALM.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace ALM.IntentProcessor
{
   public interface IUtilities
    {
        Intents IntentDetails(string strjson);
    }
}
